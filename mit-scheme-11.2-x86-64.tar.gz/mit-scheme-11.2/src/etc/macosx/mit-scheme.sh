#!/bin/bash
exec /Applications/MIT\:GNU\ Scheme.app/Contents/Resources/mit-scheme ${1+"$@"}
